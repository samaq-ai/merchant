<?php

namespace samadev\Models;

use Illuminate\Database\Eloquent\Model;

class Apps extends Model
{
    //
}
