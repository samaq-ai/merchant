
<?php $__env->startSection('content'); ?>



<!--<div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img width="64px" height="64px" src="<?php echo e(asset('images/icon.png')); ?>" />
                </a>

<a href="<?php echo e(url('/c-panel')); ?>">Refresh <i class="fa fa-refresh" aria-hidden="true"></i>
</a>-->


<img src="<?php echo e(asset('images/header.svg')); ?>" />
<!--<img src="<?php echo e(asset('images/bg-1280.svg')); ?>" />-->
<!--<p class="class">red</p>


            </div>
        </nav>
</div>
-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\cdn\samadev\resources\views/apps/index.blade.php ENDPATH**/ ?>