
  
 
<?php  // Use ls command to shell_exec 
  // function 
  $output = shell_exec('curl https://api.samabusiness.sa/api/Stores'); 
    
  // Display the list of all file 
  // and directory 
  

var_dump(json_decode($output));

?>

<?php $__env->startSection('content'); ?>

<?php echo e($timezone = config('app.timezone')); ?>

<?php echo e($appname = config('app.name')); ?>

<?php echo e($env = config('app.env')); ?>

<?php echo e($url = config('app.url')); ?>

<?php echo e($locale = config('app.locale')); ?>


<img src="<?php echo e(URL::asset('https://cdn.samabusiness.sa/v1/images/icon.jpg')); ?>" />



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.manifest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\cdn\samadev\resources\views/manifest/index.blade.php ENDPATH**/ ?>