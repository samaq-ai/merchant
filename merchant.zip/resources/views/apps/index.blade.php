@extends('layouts.apps')
@section('content')



<!--<div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                <img width="64px" height="64px" src="{{ asset('images/icon.png') }}" />
                </a>

<a href="{{ url('/c-panel')}}">Refresh <i class="fa fa-refresh" aria-hidden="true"></i>
</a>-->


<img src="{{ asset('images/header.svg') }}" />
<!--<img src="{{ asset('images/bg-1280.svg') }}" />-->
<!--<p class="class">red</p>


            </div>
        </nav>
</div>
-->


@endsection