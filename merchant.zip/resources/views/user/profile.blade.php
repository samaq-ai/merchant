@extends('layouts.manifest')

@section('content')

hi
@endsection