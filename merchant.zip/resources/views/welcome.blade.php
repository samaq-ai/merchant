@extends('layouts.manifest')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
				<h5>DB Query</h5>
				<hr />


				<div class="container">
					<div class="row justify-content-left">
						<div class="col-md-5">
							<div class="card">
								<div class="card-header">
								<label for="imgupdate" class="control-label">Update your profile picture</label>

								<div class="card-body">
									<div class="row">
										<div class="col-md-8" style="padding-left:30px">
  	
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-7">
						<div class="card">
							<div class="card-header">
								<label for="imgupdate" class="control-label"><h5>Update your personal information</h5></label>
							<div class="card-body">
							</div>
						<div class="row">
							<div class="col-md-12" style="padding-left:30px">
									<div class="form-group">   									
									</div>
	
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

@endsection


